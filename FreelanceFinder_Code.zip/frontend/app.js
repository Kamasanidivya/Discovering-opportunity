fetch('http://localhost:5000/projects')
  .then(response => response.json())
  .then(data => {
    const projectsDiv = document.getElementById('projects');
    data.forEach(project => {
        projectsDiv.innerHTML += `<p>${project.title} - $${project.budget}</p>`;
    });
  });
