from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return "Welcome to FreelanceFinder API"

@app.route('/projects', methods=['GET'])
def get_projects():
    return jsonify([{"id": 1, "title": "Build a website", "budget": 500}])

if __name__ == '__main__':
    app.run(debug=True)
